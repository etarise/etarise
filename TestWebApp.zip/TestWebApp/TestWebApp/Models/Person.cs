﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestWebApp.Models
{
    public class Person  // class person object that is hold the atrributes of a  person object
    {
      
        public string  FirstName { get; set; }  //  claas attribute firstname
        public string LastName { get; set; } //  claas attribute lastname
    }
}
